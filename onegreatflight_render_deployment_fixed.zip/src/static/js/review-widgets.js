// Review Widgets Integration
document.addEventListener('DOMContentLoaded', function() {
  // Function to load Google Reviews Widget
  function loadGoogleReviewsWidget() {
    const googleWidget = document.getElementById('google-reviews-widget');
    if (googleWidget) {
      // In a real implementation, this would be replaced with the actual Google Reviews embed code
      // For example:
      /*
      const script = document.createElement('script');
      script.src = 'https://maps.googleapis.com/maps/api/js?key=YOUR_API_KEY&libraries=places&callback=initGoogleReviews';
      script.async = true;
      document.head.appendChild(script);
      
      window.initGoogleReviews = function() {
        // Initialize the Google Places API and fetch reviews
        const service = new google.maps.places.PlacesService(googleWidget);
        service.getDetails({
          placeId: 'YOUR_PLACE_ID',
          fields: ['reviews']
        }, function(place, status) {
          if (status === google.maps.places.PlacesServiceStatus.OK) {
            // Render reviews
            renderGoogleReviews(place.reviews);
          }
        });
      };
      */
      
      // Placeholder for demonstration
      googleWidget.innerHTML = `
        <div style="text-align: center; padding: 20px; background-color: #f8f9fa; height: 100%; display: flex; flex-direction: column; justify-content: center; align-items: center;">
          <i class="fab fa-google" style="font-size: 48px; color: #4285F4; margin-bottom: 20px;"></i>
          <h3 style="margin-bottom: 15px;">Google Reviews</h3>
          <div style="display: flex; margin-bottom: 15px;">
            <i class="fas fa-star" style="color: #FBBC05;"></i>
            <i class="fas fa-star" style="color: #FBBC05;"></i>
            <i class="fas fa-star" style="color: #FBBC05;"></i>
            <i class="fas fa-star" style="color: #FBBC05;"></i>
            <i class="fas fa-star" style="color: #FBBC05;"></i>
          </div>
          <p style="font-weight: bold; margin-bottom: 10px;">5.0 out of 5 stars</p>
          <p>Based on 47 reviews</p>
          <a href="#" style="display: inline-block; margin-top: 20px; padding: 10px 20px; background-color: #4285F4; color: white; text-decoration: none; border-radius: 4px;">View All Reviews</a>
        </div>
      `;
    }
  }
  
  // Function to load Trustpilot Widget
  function loadTrustpilotWidget() {
    const trustpilotWidget = document.getElementById('trustpilot-widget');
    if (trustpilotWidget) {
      // In a real implementation, this would be replaced with the actual Trustpilot embed code
      // For example:
      /*
      const script = document.createElement('script');
      script.src = 'https://widget.trustpilot.com/bootstrap/v5/tp.widget.bootstrap.min.js';
      script.async = true;
      script.dataset.businessunitId = 'YOUR_BUSINESS_UNIT_ID';
      script.dataset.templateId = 'YOUR_TEMPLATE_ID';
      trustpilotWidget.appendChild(script);
      */
      
      // Placeholder for demonstration
      trustpilotWidget.innerHTML = `
        <div style="text-align: center; padding: 20px; background-color: #f8f9fa; height: 100%; display: flex; flex-direction: column; justify-content: center; align-items: center;">
          <div style="background-color: #00b67a; color: white; padding: 10px 15px; border-radius: 4px; margin-bottom: 20px;">
            <i class="fas fa-star" style="color: white;"></i> Trustpilot
          </div>
          <h3 style="margin-bottom: 15px;">Trustpilot Reviews</h3>
          <div style="display: flex; margin-bottom: 15px;">
            <i class="fas fa-star" style="color: #00b67a;"></i>
            <i class="fas fa-star" style="color: #00b67a;"></i>
            <i class="fas fa-star" style="color: #00b67a;"></i>
            <i class="fas fa-star" style="color: #00b67a;"></i>
            <i class="fas fa-star" style="color: #00b67a;"></i>
          </div>
          <p style="font-weight: bold; margin-bottom: 10px;">Excellent</p>
          <p>Based on 38 reviews</p>
          <a href="#" style="display: inline-block; margin-top: 20px; padding: 10px 20px; background-color: #00b67a; color: white; text-decoration: none; border-radius: 4px;">View All Reviews</a>
        </div>
      `;
    }
  }
  
  // Function to load Yelp Widget
  function loadYelpWidget() {
    const yelpWidget = document.getElementById('yelp-widget');
    if (yelpWidget) {
      // In a real implementation, this would be replaced with the actual Yelp embed code
      // For example:
      /*
      const script = document.createElement('script');
      script.src = 'https://www.yelp.com/embed/widgets.js';
      script.async = true;
      script.dataset.businessId = 'YOUR_BUSINESS_ID';
      yelpWidget.appendChild(script);
      */
      
      // Placeholder for demonstration
      yelpWidget.innerHTML = `
        <div style="text-align: center; padding: 20px; background-color: #f8f9fa; height: 100%; display: flex; flex-direction: column; justify-content: center; align-items: center;">
          <i class="fab fa-yelp" style="font-size: 48px; color: #d32323; margin-bottom: 20px;"></i>
          <h3 style="margin-bottom: 15px;">Yelp Reviews</h3>
          <div style="display: flex; margin-bottom: 15px;">
            <i class="fas fa-star" style="color: #d32323;"></i>
            <i class="fas fa-star" style="color: #d32323;"></i>
            <i class="fas fa-star" style="color: #d32323;"></i>
            <i class="fas fa-star" style="color: #d32323;"></i>
            <i class="fas fa-star" style="color: #d32323;"></i>
          </div>
          <p style="font-weight: bold; margin-bottom: 10px;">5.0 out of 5 stars</p>
          <p>Based on 29 reviews</p>
          <a href="#" style="display: inline-block; margin-top: 20px; padding: 10px 20px; background-color: #d32323; color: white; text-decoration: none; border-radius: 4px;">View All Reviews</a>
        </div>
      `;
    }
  }
  
  // Load all review widgets
  loadGoogleReviewsWidget();
  loadTrustpilotWidget();
  loadYelpWidget();
});
