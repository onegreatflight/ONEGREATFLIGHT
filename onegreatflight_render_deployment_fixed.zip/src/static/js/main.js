// OneGreatFlight.com - Main JavaScript

document.addEventListener('DOMContentLoaded', function() {
    // Form validation
    const form = document.getElementById('flight-inquiry-form');
    
    if (form) {
        form.addEventListener('submit', function(e) {
            e.preventDefault();
            
            // Basic validation
            let isValid = true;
            const requiredFields = form.querySelectorAll('[required]');
            
            requiredFields.forEach(field => {
                if (!field.value.trim()) {
                    isValid = false;
                    field.classList.add('is-invalid');
                } else {
                    field.classList.remove('is-invalid');
                }
            });
            
            // Email validation
            const emailField = form.querySelector('input[type="email"]');
            if (emailField && emailField.value) {
                const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
                if (!emailPattern.test(emailField.value)) {
                    isValid = false;
                    emailField.classList.add('is-invalid');
                }
            }
            
            // Phone validation
            const phoneField = form.querySelector('input[name="phone"]');
            if (phoneField && phoneField.value) {
                const phonePattern = /^[0-9+\s()-]{8,20}$/;
                if (!phonePattern.test(phoneField.value)) {
                    isValid = false;
                    phoneField.classList.add('is-invalid');
                }
            }
            
            // Date validation
            const departureDate = form.querySelector('input[name="departure_date"]');
            const returnDate = form.querySelector('input[name="return_date"]');
            
            if (departureDate && returnDate && departureDate.value && returnDate.value) {
                const depDate = new Date(departureDate.value);
                const retDate = new Date(returnDate.value);
                
                if (retDate < depDate) {
                    isValid = false;
                    returnDate.classList.add('is-invalid');
                    alert('Return date cannot be earlier than departure date');
                }
            }
            
            if (isValid) {
                // Show loading state
                const submitBtn = form.querySelector('button[type="submit"]');
                const originalText = submitBtn.textContent;
                submitBtn.disabled = true;
                submitBtn.textContent = 'Sending...';
                
                // Submit form data
                const formData = new FormData(form);
                
                fetch('/submit-inquiry', {
                    method: 'POST',
                    body: formData
                })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        // Show success message
                        form.reset();
                        document.getElementById('form-success').style.display = 'block';
                        document.getElementById('form-error').style.display = 'none';
                    } else {
                        // Show error message
                        document.getElementById('form-error').style.display = 'block';
                        document.getElementById('form-success').style.display = 'none';
                    }
                })
                .catch(error => {
                    console.error('Error:', error);
                    document.getElementById('form-error').style.display = 'block';
                    document.getElementById('form-success').style.display = 'none';
                })
                .finally(() => {
                    // Reset button state
                    submitBtn.disabled = false;
                    submitBtn.textContent = originalText;
                });
            }
        });
    }
    
    // Date picker initialization
    const dateInputs = document.querySelectorAll('input[type="date"]');
    dateInputs.forEach(input => {
        // Set min date to today
        const today = new Date().toISOString().split('T')[0];
        input.setAttribute('min', today);
    });
    
    // Smooth scrolling for anchor links
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function(e) {
            e.preventDefault();
            
            const targetId = this.getAttribute('href');
            if (targetId === '#') return;
            
            const targetElement = document.querySelector(targetId);
            if (targetElement) {
                window.scrollTo({
                    top: targetElement.offsetTop - 100,
                    behavior: 'smooth'
                });
            }
        });
    });
});
