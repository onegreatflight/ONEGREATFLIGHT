// Banner Animation JavaScript
document.addEventListener('DOMContentLoaded', function() {
  const slides = document.querySelectorAll('.banner-slide');
  let currentSlide = 0;
  
  // Function to change slides
  function nextSlide() {
    // Remove active class from current slide
    slides[currentSlide].classList.remove('active');
    
    // Move to next slide or back to first slide
    currentSlide = (currentSlide + 1) % slides.length;
    
    // Add active class to new current slide
    slides[currentSlide].classList.add('active');
  }
  
  // Set first slide as active initially
  slides[0].classList.add('active');
  
  // Change slides every 5 seconds
  setInterval(nextSlide, 5000);
  
  // Form validation and enhancement
  const searchForm = document.getElementById('flight-search-form');
  if (searchForm) {
    searchForm.addEventListener('submit', function(e) {
      e.preventDefault();
      
      // Get form data
      const formData = new FormData(searchForm);
      const formObject = {};
      formData.forEach((value, key) => {
        formObject[key] = value;
      });
      
      // Send form data to server (in real implementation)
      console.log('Search form submitted:', formObject);
      
      // For demo purposes, show success message
      alert('Thank you for your inquiry! We will contact you shortly with the best flight options.');
      
      // Optional: Reset form
      searchForm.reset();
    });
  }
});
