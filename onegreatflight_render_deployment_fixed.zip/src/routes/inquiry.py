from flask import Flask, render_template, request, jsonify, Blueprint
import os
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart

inquiry_bp = Blueprint('inquiry', __name__)

@inquiry_bp.route('/submit-inquiry', methods=['POST'])
def submit_inquiry():
    try:
        # Get form data
        first_name = request.form.get('first_name', '')
        last_name = request.form.get('last_name', '')
        email = request.form.get('email', '')
        phone = request.form.get('phone', '')
        contact_preference = request.form.get('contact_preference', 'email')
        
        # Travel details
        departure_city = request.form.get('departure_city', '')
        destination_city = request.form.get('destination_city', '')
        if destination_city == 'Other':
            destination_city = request.form.get('other_destination', '')
        
        departure_date = request.form.get('departure_date', '')
        return_date = request.form.get('return_date', '')
        passengers = request.form.get('passengers', '1')
        class_preference = request.form.get('class_preference', 'Business')
        airline_preference = request.form.get('airline_preference', '')
        
        # Additional information
        special_requirements = request.form.get('special_requirements', '')
        referral_source = request.form.get('referral_source', '')
        subscribe = 'Yes' if request.form.get('subscribe') == 'yes' else 'No'
        
        # Create email content
        email_subject = f"New Flight Inquiry: {first_name} {last_name} - {departure_city} to {destination_city}"
        
        email_body = f"""
        <html>
        <head>
            <style>
                body {{ font-family: Arial, sans-serif; line-height: 1.6; color: #333; }}
                .container {{ max-width: 600px; margin: 0 auto; padding: 20px; }}
                h1 {{ color: #0c4da2; }}
                h2 {{ color: #0c4da2; margin-top: 20px; }}
                .section {{ margin-bottom: 20px; }}
                .label {{ font-weight: bold; }}
                .highlight {{ background-color: #f8f9fa; padding: 15px; border-left: 4px solid #0c4da2; }}
            </style>
        </head>
        <body>
            <div class="container">
                <h1>New Flight Inquiry</h1>
                <p>A new inquiry has been submitted through OneGreatFlight.com</p>
                
                <div class="section highlight">
                    <h2>Personal Information</h2>
                    <p><span class="label">Name:</span> {first_name} {last_name}</p>
                    <p><span class="label">Email:</span> {email}</p>
                    <p><span class="label">Phone:</span> {phone}</p>
                    <p><span class="label">Preferred Contact Method:</span> {contact_preference}</p>
                </div>
                
                <div class="section highlight">
                    <h2>Travel Details</h2>
                    <p><span class="label">Route:</span> {departure_city} to {destination_city}</p>
                    <p><span class="label">Departure Date:</span> {departure_date}</p>
                    <p><span class="label">Return Date:</span> {return_date}</p>
                    <p><span class="label">Number of Passengers:</span> {passengers}</p>
                    <p><span class="label">Class Preference:</span> {class_preference}</p>
                    <p><span class="label">Airline Preference:</span> {airline_preference if airline_preference else 'No preference specified'}</p>
                </div>
                
                <div class="section highlight">
                    <h2>Additional Information</h2>
                    <p><span class="label">Special Requirements:</span> {special_requirements if special_requirements else 'None specified'}</p>
                    <p><span class="label">Referral Source:</span> {referral_source if referral_source else 'Not specified'}</p>
                    <p><span class="label">Subscribe to Offers:</span> {subscribe}</p>
                </div>
                
                <p>Please respond to this inquiry as soon as possible.</p>
            </div>
        </body>
        </html>
        """
        
        # For demonstration purposes, we'll log the email content
        # In production, this would send an actual email
        print(f"Subject: {email_subject}")
        print(f"Would send email to: onegreatflight@gmail.com")
        print(f"Email content: {email_body}")
        
        # In a real implementation, you would use something like:
        # send_email(email_subject, email_body, recipient_email)
        
        # For now, we'll simulate successful email sending
        return jsonify({"success": True, "message": "Inquiry submitted successfully"})
        
    except Exception as e:
        print(f"Error processing form: {str(e)}")
        return jsonify({"success": False, "message": f"Error: {str(e)}"}), 500

def send_email(subject, body, recipient_email):
    """
    Function to send email using SMTP
    Note: In production, you would use environment variables for credentials
    """
    sender_email = os.environ.get('EMAIL_USER', 'onegreatflight@gmail.com')
    password = os.environ.get('EMAIL_PASSWORD', 'your-password')
    smtp_server = os.environ.get('SMTP_SERVER', 'smtp.example.com')
    smtp_port = int(os.environ.get('SMTP_PORT', 587))
    
    message = MIMEMultipart('alternative')
    message['Subject'] = subject
    message['From'] = sender_email
    message['To'] = recipient_email
    
    # Attach HTML content
    html_part = MIMEText(body, 'html')
    message.attach(html_part)
    
    try:
        server = smtplib.SMTP(smtp_server, smtp_port)
        server.starttls()
        server.login(sender_email, password)
        server.sendmail(sender_email, recipient_email, message.as_string())
        server.quit()
        return True
    except Exception as e:
        print(f"Failed to send email: {str(e)}")
        return False
